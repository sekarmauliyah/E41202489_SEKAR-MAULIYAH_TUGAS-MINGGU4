package com.example.text

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
