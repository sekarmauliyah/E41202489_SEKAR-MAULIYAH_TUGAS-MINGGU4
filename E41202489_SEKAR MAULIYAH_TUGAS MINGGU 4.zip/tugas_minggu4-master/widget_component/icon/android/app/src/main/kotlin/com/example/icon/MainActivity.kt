package com.example.icon

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
